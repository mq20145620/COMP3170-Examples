package java.io;

public interface ObjectOutput extends DataOutput {
	void writeObject(Object obj);
}
