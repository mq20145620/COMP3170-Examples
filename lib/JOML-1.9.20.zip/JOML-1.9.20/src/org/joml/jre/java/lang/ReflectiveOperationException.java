package java.lang;

public class ReflectiveOperationException extends Exception {}
